export declare class ActorMaker {
    static makeActor(): Promise<void>;
}
