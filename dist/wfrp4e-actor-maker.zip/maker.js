"use strict";
(() => {
  // src/util/register-settings.ts
  var RegisterSettings = class {
    static initSettings() {
      const mainModule = "wfrp4-actor-maker";
      this.moduleName = mainModule;
      this.registerSettings(mainModule);
    }
    static registerSettings(moduleName) {
      game.settings.register(moduleName, "defaultCustomGeneration", {
        name: game.i18n.localize("ACTORMAKER.settings.defaultCustomGeneration.name"),
        hint: game.i18n.localize("ACTORMAKER.settings.defaultCustomGeneration.hint"),
        scope: "world",
        config: true,
        type: Boolean,
        default: true
      });
    }
  };

  // src/modules/makers/actor-maker.ts
  var ActorMaker = class {
    static async makeActor() {
      console.log("Button pushed!");
    }
  };

  // src/maker.ts
  Hooks.once("init", () => {
    RegisterSettings.initSettings();
    Handlebars.registerHelper("json", (context) => {
      return JSON.stringify(context);
    });
  });
  Hooks.on("renderActorDirectory", (_app, html) => {
    if (game.user.can("ACTOR_CREATE")) {
      addActorActionButton(html, "ACTORMAKER.actor.directory.button", () => {
        ActorMaker.makeActor();
      });
    }
  });
  function addActorActionButton(html, label, onClick) {
    const button = document.createElement("button");
    button.style.width = "95%";
    button.innerHTML = game.i18n.localize(label);
    button.addEventListener("click", () => {
      onClick();
    });
    html.find(".header-actions").after(button);
  }
})();
