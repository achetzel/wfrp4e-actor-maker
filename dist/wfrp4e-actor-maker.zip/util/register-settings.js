import { i18n, settings } from '../constants';
export default class RegisterSettings {
    static initSettings() {
        const mainModule = 'wfrp4-actor-maker';
        this.moduleName = mainModule;
        this.registerSettings(mainModule);
    }
    static registerSettings(moduleName) {
        settings().register(moduleName, 'defaultCustomGeneration', {
            name: i18n().localize('ACTORMAKER.settings.defaultCustomGeneration.name'),
            hint: i18n().localize('ACTORMAKER.settings.defaultCustomGeneration.hint'),
            scope: 'world',
            config: true,
            type: Boolean,
            default: true,
        });
    }
}
//# sourceMappingURL=register-settings.js.map