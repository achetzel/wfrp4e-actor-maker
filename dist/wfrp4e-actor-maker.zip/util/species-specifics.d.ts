export declare class SpeciesSpecifics {
    static getSpecies(): Promise<void>;
    static getSubSpecies(subspecies: string): Promise<void>;
    static getSpeciesSkills(species: string, subspecies?: string): Promise<void>;
    static getSpeciesTalents(species: string, subspecies?: string): Promise<void>;
}
