var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
import { wfrp4e } from '../constants';
//import { actors, i18n, initTemplates, user, wfrp4e } from '../constants';
export class SpeciesSpecifics {
    static getSpecies() {
        return __awaiter(this, void 0, void 0, function* () {
            yield wfrp4e().config.species;
        });
    }
    static getSubSpecies(subspecies) {
        return __awaiter(this, void 0, void 0, function* () {
            yield wfrp4e().config.subspecies[subspecies];
        });
    }
    static getSpeciesSkills(species, subspecies) {
        return __awaiter(this, void 0, void 0, function* () {
            yield wfrp4e().utility.speciesSkillsTalents(species, subspecies)['skills'];
        });
    }
    static getSpeciesTalents(species, subspecies) {
        return __awaiter(this, void 0, void 0, function* () {
            let talentList = yield wfrp4e().utility.speciesSkillsTalents(species, subspecies)['talents'];
            let refinedTalentList = [];
            for (let talent of talentList) {
                if (!isNaN(talent)) {
                    for (let i = 0; i < talent; i++) {
                        refinedTalentList.push((yield wfrp4e().tables.rollTable("talents")).object.text);
                    }
                    continue;
                }
                else {
                    refinedTalentList.push(talent);
                }
            }
        });
    }
}
//# sourceMappingURL=species-specifics.js.map